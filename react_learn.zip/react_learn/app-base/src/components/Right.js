import React from 'react'


function Right(){
  let styles = {
    width: "200px",
    height: "100px",
    backgroundColor: "yellow",
    cssFloat: "right"
  };

  return (
    <section style={styles}>我是右边栏</section>
  );
}

export default Right;
